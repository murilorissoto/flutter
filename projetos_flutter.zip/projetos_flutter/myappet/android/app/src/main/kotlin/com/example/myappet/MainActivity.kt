package com.example.myappet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
